## 题目描述
CrackMe02

## 解题
下载附件，也是一个Windows API程序，按照[CrackMe01](./CrackMe01)；
放入exeinfope：
![](https://ps.feiyunote.cn/assets/image-20240304200755206.png)

无壳32位程序，放入32位IDA