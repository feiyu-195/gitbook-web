## 题目描述
find the flag

## 解题
下载附件，`wireshark`打开发现包损坏，用`010Editor`打开搜索`flag`：

> 010Editor是与winhex相同类型的工具。

![](https://ps.feiyunote.cn/assets/image-20240228150715880.png)

在查看中选择编辑为文本，查看搜索到的flag，找到关键信息：
![](https://ps.feiyunote.cn/assets/image-20240228150839057.png)

将信息记录下来得到`flag{aha!_you_found_it!}`