## 题目描述
embarrass
## 解题
解题方式与[find_the_flag](./find_the_flag.md)相同
下载附件，查看流量包未发现关键信息，使用`010editor`打开搜索`flag`关键字，在查看中选择编辑为文本
查看搜索的`flag`信息，找到`flag{Good_b0y_W3ll_Done}`
![](https://ps.feiyunote.cn/assets/image-20240228152814344.png)

